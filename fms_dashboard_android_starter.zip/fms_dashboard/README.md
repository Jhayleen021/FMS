# FMS Dashboard — Android starter

A local-first Flutter prototype for importing CSV exports you are authorized to access. It does not log into FMS, scrape the portal, or connect to an SPX API.

## Included
- Import CSV via Android file picker
- Header-aware parsing with tolerant column-name matching
- Local SQLite storage
- Dashboard counts based on imported data
- Search by tracking number, order ID, or Shopee order number
- Filter by status and order account
- Order detail view
- Import timestamp and row-count feedback

## Run
1. Install Flutter SDK and Android Studio.
2. Extract this ZIP.
3. In this directory run:
   ```bash
   flutter pub get
   flutter run
   ```
4. Connect an Android phone with USB debugging enabled, or start an Android emulator.
5. Use **Import CSV** to choose an authorized FMS export.

## Notes
- This starter currently imports CSV, not `.xlsx`. Excel can usually save/export as CSV. Native `.xlsx` support can be added next.
- It stores data locally in the app's SQLite database. Uninstalling the app may delete that data.
- Test using a sanitized export first. The importer stores the original CSV row as JSON to preserve available fields; do not import personal or confidential data unless your organization permits it.
- Status totals represent the most recently imported record for each order key, not a live FMS count.
- The importer uses `SLS Tracking Number`, then `Order ID`, then `Shopee Order SN` as the record key. Review this rule against your operational workflow before relying on it.
- This is source code, not a compiled APK. Build and test it in your own approved development environment.
