import 'dart:convert';

class FmsOrder {
  const FmsOrder({
    required this.keyValue,
    required this.trackingNumber,
    required this.orderId,
    required this.orderSn,
    required this.status,
    required this.account,
    required this.currentStation,
    required this.destinationStation,
    required this.createdTime,
    required this.rawJson,
  });

  final String keyValue;
  final String trackingNumber;
  final String orderId;
  final String orderSn;
  final String status;
  final String account;
  final String currentStation;
  final String destinationStation;
  final String createdTime;
  final String rawJson;

  Map<String, Object?> toMap() => {
        'key_value': keyValue,
        'tracking_number': trackingNumber,
        'order_id': orderId,
        'order_sn': orderSn,
        'status': status,
        'account': account,
        'current_station': currentStation,
        'destination_station': destinationStation,
        'created_time': createdTime,
        'raw_json': rawJson,
      };

  factory FmsOrder.fromMap(Map<String, Object?> map) => FmsOrder(
        keyValue: map['key_value'] as String? ?? '',
        trackingNumber: map['tracking_number'] as String? ?? '',
        orderId: map['order_id'] as String? ?? '',
        orderSn: map['order_sn'] as String? ?? '',
        status: map['status'] as String? ?? 'Unknown',
        account: map['account'] as String? ?? '',
        currentStation: map['current_station'] as String? ?? '',
        destinationStation: map['destination_station'] as String? ?? '',
        createdTime: map['created_time'] as String? ?? '',
        rawJson: map['raw_json'] as String? ?? '{}',
      );

  Map<String, dynamic> get rawFields {
    try {
      final decoded = jsonDecode(rawJson);
      if (decoded is Map<String, dynamic>) return decoded;
    } catch (_) {
      // Fall through to an empty map for malformed legacy rows.
    }
    return const {};
  }
}
