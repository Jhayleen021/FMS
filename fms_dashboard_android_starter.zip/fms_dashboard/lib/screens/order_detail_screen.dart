import 'package:flutter/material.dart';
import '../models/order.dart';

class OrderDetailScreen extends StatelessWidget {
  const OrderDetailScreen({super.key, required this.order});
  final FmsOrder order;

  @override
  Widget build(BuildContext context) {
    final fields = order.rawFields.entries
        .where((e) => e.value.toString().trim().isNotEmpty)
        .toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Order details')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('TRACKING NUMBER', style: TextStyle(fontSize: 11, letterSpacing: 1, color: Colors.black54)),
                const SizedBox(height: 6),
                SelectableText(
                  order.trackingNumber.isEmpty ? 'Not available' : order.trackingNumber,
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                _detail('Status', order.status),
                _detail('Order ID', order.orderId),
                _detail('Order account', order.account),
                _detail('Current station', order.currentStation),
                _detail('Destination station', order.destinationStation),
                _detail('Created time', order.createdTime),
              ]),
            ),
          ),
          const SizedBox(height: 14),
          const Text('Imported fields', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Card(
            child: Column(
              children: fields.map((entry) => ListTile(
                dense: true,
                title: Text(entry.key, style: const TextStyle(fontSize: 12, color: Colors.black54)),
                subtitle: SelectableText(entry.value.toString(), style: const TextStyle(fontSize: 14)),
              )).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _detail(String label, String value) => Padding(
    padding: const EdgeInsets.only(top: 8),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SizedBox(width: 124, child: Text(label, style: const TextStyle(color: Colors.black54))),
      Expanded(child: Text(value.isEmpty ? '—' : value)),
    ]),
  );
}
