import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../models/order.dart';
import '../services/csv_import_service.dart';
import '../services/database_service.dart';
import 'order_detail_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final _searchController = TextEditingController();
  List<FmsOrder> _orders = [];
  Map<String, int> _counts = {};
  List<String> _accounts = ['All accounts'];
  String _status = 'All statuses';
  String _account = 'All accounts';
  bool _loading = true;
  String? _lastImport;
  String? _message;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _refresh() async {
    setState(() => _loading = true);
    final db = DatabaseService.instance;
    final results = await Future.wait([
      db.getOrders(search: _searchController.text, status: _status, account: _account),
      db.getStatusCounts(),
      db.getAccounts(),
    ]);
    if (!mounted) return;
    setState(() {
      _orders = results[0] as List<FmsOrder>;
      _counts = results[1] as Map<String, int>;
      _accounts = results[2] as List<String>;
      _loading = false;
    });
  }

  Future<void> _importCsv() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['csv'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return;
    final file = result.files.single;
    final bytes = file.bytes;
    if (bytes == null) {
      setState(() => _message = 'Could not read the selected file. Please choose it again.');
      return;
    }
    final parsed = parseFmsCsv(bytes);
    if (parsed.orders.isEmpty) {
      setState(() => _message = parsed.warnings.join('\n').isEmpty
          ? 'No order rows found.' : parsed.warnings.join('\n'));
      return;
    }

    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirm import'),
        content: Text(
          'File: ${file.name}\n'
          'Rows read: ${parsed.rowsRead}\n'
          'Valid orders: ${parsed.orders.length}\n'
          'Skipped rows: ${parsed.skippedRows}\n\n'
          'This will add or update records in the local database.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Import')),
        ],
      ),
    );
    if (confirm != true) return;

    final changed = await DatabaseService.instance.upsertOrders(parsed.orders);
    if (!mounted) return;
    setState(() {
      _lastImport = DateTime.now().toLocal().toString().substring(0, 16);
      _message = 'Imported ${parsed.orders.length} orders from ${file.name}. '
          '$changed records processed.'
          '${parsed.warnings.isEmpty ? '' : '\n${parsed.warnings.join('\n')}'}';
    });
    await _refresh();
  }

  int get _total => _counts.values.fold(0, (a, b) => a + b);

  @override
  Widget build(BuildContext context) {
    final statuses = ['All statuses', ..._counts.keys];
    return Scaffold(
      appBar: AppBar(
        title: const Text('FMS Dashboard', style: TextStyle(fontWeight: FontWeight.w700)),
        actions: [
          IconButton(
            tooltip: 'Import CSV',
            onPressed: _importCsv,
            icon: const Icon(Icons.file_upload_outlined),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                gradient: const LinearGradient(
                  colors: [Color(0xFF272D3A), Color(0xFF454D5D)],
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('ORDER OVERVIEW', style: TextStyle(color: Colors.white70, letterSpacing: 1.2, fontSize: 12)),
                  const SizedBox(height: 8),
                  Text('$_total', style: const TextStyle(color: Colors.white, fontSize: 36, fontWeight: FontWeight.bold)),
                  const Text('Orders in local database', style: TextStyle(color: Colors.white70)),
                  const SizedBox(height: 12),
                  Text(
                    _lastImport == null ? 'Import an authorized FMS CSV to get started.' : 'Last imported: $_lastImport',
                    style: const TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Row(children: [
              Expanded(child: _summaryCard('Statuses', '${_counts.length}', Icons.local_shipping_outlined)),
              const SizedBox(width: 10),
              Expanded(child: _summaryCard('Accounts', '${_accounts.length - 1}', Icons.storefront_outlined)),
            ]),
            const SizedBox(height: 18),
            TextField(
              controller: _searchController,
              onChanged: (_) => _refresh(),
              decoration: InputDecoration(
                hintText: 'Search tracking number or order ID',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.clear),
                  onPressed: () { _searchController.clear(); _refresh(); },
                ),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(
                child: DropdownButtonFormField<String>(
                  value: _status,
                  isExpanded: true,
                  decoration: const InputDecoration(labelText: 'Status', border: OutlineInputBorder()),
                  items: statuses.map((s) => DropdownMenuItem(value: s, child: Text(s, overflow: TextOverflow.ellipsis))).toList(),
                  onChanged: (v) { if (v != null) { _status = v; _refresh(); } },
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: DropdownButtonFormField<String>(
                  value: _accounts.contains(_account) ? _account : 'All accounts',
                  isExpanded: true,
                  decoration: const InputDecoration(labelText: 'Account', border: OutlineInputBorder()),
                  items: _accounts.map((a) => DropdownMenuItem(value: a, child: Text(a, overflow: TextOverflow.ellipsis))).toList(),
                  onChanged: (v) { if (v != null) { _account = v; _refresh(); } },
                ),
              ),
            ]),
            const SizedBox(height: 18),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Orders', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                Text('${_orders.length} shown', style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
            const SizedBox(height: 8),
            if (_message != null)
              Card(
                child: ListTile(
                  leading: const Icon(Icons.info_outline),
                  title: Text(_message!),
                  trailing: IconButton(icon: const Icon(Icons.close), onPressed: () => setState(() => _message = null)),
                ),
              ),
            if (_loading)
              const Padding(padding: EdgeInsets.all(32), child: Center(child: CircularProgressIndicator()))
            else if (_orders.isEmpty)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(children: [
                    const Icon(Icons.inventory_2_outlined, size: 42, color: Colors.grey),
                    const SizedBox(height: 10),
                    Text(_total == 0 ? 'No orders imported yet' : 'No matching orders'),
                    const SizedBox(height: 6),
                    const Text('Tap the upload icon to import a CSV export.', textAlign: TextAlign.center),
                    const SizedBox(height: 12),
                    FilledButton.icon(onPressed: _importCsv, icon: const Icon(Icons.upload_file), label: const Text('Import CSV')),
                  ]),
                ),
              )
            else
              ..._orders.map((order) => Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.local_shipping_outlined)),
                  title: Text(order.trackingNumber.isEmpty ? order.orderId : order.trackingNumber,
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: Text([
                    if (order.status.isNotEmpty) order.status,
                    if (order.account.isNotEmpty) order.account,
                    if (order.destinationStation.isNotEmpty) order.destinationStation,
                  ].join(' • '), maxLines: 2, overflow: TextOverflow.ellipsis),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => OrderDetailScreen(order: order),
                  )),
                ),
              )),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _importCsv,
        icon: const Icon(Icons.file_upload_outlined),
        label: const Text('Import CSV'),
      ),
    );
  }

  Widget _summaryCard(String label, String value, IconData icon) => Card(
    child: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: Theme.of(context).colorScheme.primary),
        const SizedBox(height: 10),
        Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        Text(label, style: const TextStyle(color: Colors.black54)),
      ]),
    ),
  );
}
