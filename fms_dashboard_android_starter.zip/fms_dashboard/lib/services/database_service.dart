import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import '../models/order.dart';

class DatabaseService {
  DatabaseService._();
  static final DatabaseService instance = DatabaseService._();
  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    final root = await getDatabasesPath();
    _database = await openDatabase(
      p.join(root, 'fms_dashboard.db'),
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE orders (
            key_value TEXT PRIMARY KEY,
            tracking_number TEXT,
            order_id TEXT,
            order_sn TEXT,
            status TEXT,
            account TEXT,
            current_station TEXT,
            destination_station TEXT,
            created_time TEXT,
            raw_json TEXT
          )
        ''');
        await db.execute('CREATE INDEX idx_orders_status ON orders(status)');
        await db.execute('CREATE INDEX idx_orders_account ON orders(account)');
      },
    );
    return _database!;
  }

  Future<int> upsertOrders(List<FmsOrder> orders) async {
    final db = await database;
    var changed = 0;
    await db.transaction((txn) async {
      final batch = txn.batch();
      for (final order in orders) {
        batch.insert(
          'orders',
          order.toMap(),
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
        changed++;
      }
      await batch.commit(noResult: true);
    });
    return changed;
  }

  Future<List<FmsOrder>> getOrders({
    String search = '',
    String status = 'All statuses',
    String account = 'All accounts',
  }) async {
    final db = await database;
    final clauses = <String>[];
    final args = <Object?>[];
    final q = search.trim();
    if (q.isNotEmpty) {
      clauses.add('(tracking_number LIKE ? OR order_id LIKE ? OR order_sn LIKE ?)');
      final pattern = '%$q%';
      args.addAll([pattern, pattern, pattern]);
    }
    if (status != 'All statuses') {
      clauses.add('status = ?');
      args.add(status);
    }
    if (account != 'All accounts') {
      clauses.add('account = ?');
      args.add(account);
    }
    final rows = await db.query(
      'orders',
      where: clauses.isEmpty ? null : clauses.join(' AND '),
      whereArgs: args.isEmpty ? null : args,
      orderBy: 'created_time DESC, tracking_number ASC',
    );
    return rows.map(FmsOrder.fromMap).toList();
  }

  Future<Map<String, int>> getStatusCounts() async {
    final db = await database;
    final rows = await db.rawQuery(
      'SELECT status, COUNT(*) AS total FROM orders GROUP BY status ORDER BY total DESC',
    );
    return {
      for (final row in rows)
        (row['status'] as String? ?? 'Unknown'):
            (row['total'] as int? ?? 0),
    };
  }

  Future<List<String>> getAccounts() async {
    final db = await database;
    final rows = await db.rawQuery(
      "SELECT DISTINCT account FROM orders WHERE account IS NOT NULL AND account != '' ORDER BY account",
    );
    return ['All accounts', ...rows.map((r) => r['account'] as String)];
  }

  Future<int> getOrderCount() async {
    final db = await database;
    final result = await db.rawQuery('SELECT COUNT(*) AS total FROM orders');
    return Sqflite.firstIntValue(result) ?? 0;
  }

  Future<void> clearOrders() async {
    final db = await database;
    await db.delete('orders');
  }
}
