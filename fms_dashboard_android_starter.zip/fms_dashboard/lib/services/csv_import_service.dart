import 'dart:convert';
import 'package:csv/csv.dart';
import '../models/order.dart';

class CsvImportResult {
  const CsvImportResult({
    required this.orders,
    required this.rowsRead,
    required this.skippedRows,
    required this.warnings,
  });
  final List<FmsOrder> orders;
  final int rowsRead;
  final int skippedRows;
  final List<String> warnings;
}

String _normalize(String value) =>
    value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

String _value(Map<String, String> row, List<String> aliases) {
  for (final entry in row.entries) {
    final key = _normalize(entry.key);
    if (aliases.any((alias) => key == _normalize(alias))) {
      return entry.value.trim();
    }
  }
  return '';
}

CsvImportResult parseFmsCsv(List<int> bytes) {
  // UTF-8 with BOM is handled by removing the BOM from the decoded text.
  var text = utf8.decode(bytes, allowMalformed: true);
  text = text.replaceFirst('﻿', '');
  final rows = const CsvToListConverter(
    shouldParseNumbers: false,
    eol: '\n',
  ).convert(text);

  if (rows.isEmpty) {
    return const CsvImportResult(
      orders: [], rowsRead: 0, skippedRows: 0,
      warnings: ['The file is empty.'],
    );
  }

  final headers = rows.first.map((v) => v?.toString().trim() ?? '').toList();
  final headerKeys = headers.map(_normalize).toSet();
  final hasTracking = headerKeys.contains(_normalize('SLS Tracking Number')) ||
      headerKeys.contains(_normalize('SPX Tracking Number')) ||
      headerKeys.contains(_normalize('Tracking Number'));
  final hasOrderId = headerKeys.contains(_normalize('Order ID'));
  if (!hasTracking && !hasOrderId) {
    return const CsvImportResult(
      orders: [], rowsRead: 0, skippedRows: 0,
      warnings: ['Required columns not found. Expected a tracking-number or Order ID column.'],
    );
  }

  final parsed = <FmsOrder>[];
  final seen = <String>{};
  var skipped = 0;
  for (var i = 1; i < rows.length; i++) {
    final cells = rows[i];
    if (cells.every((cell) => (cell?.toString().trim() ?? '').isEmpty)) continue;
    final row = <String, String>{};
    for (var j = 0; j < headers.length; j++) {
      row[headers[j]] = j < cells.length ? (cells[j]?.toString() ?? '') : '';
    }

    final tracking = _value(row, [
      'SLS Tracking Number', 'SPX Tracking Number', 'Tracking Number',
    ]);
    final orderId = _value(row, ['Order ID']);
    final orderSn = _value(row, ['Shopee Order SN']);
    final key = tracking.isNotEmpty
        ? 'tracking:$tracking'
        : orderId.isNotEmpty
            ? 'order:$orderId'
            : orderSn.isNotEmpty
                ? 'sn:$orderSn'
                : '';
    if (key.isEmpty) {
      skipped++;
      continue;
    }
    if (!seen.add(key)) {
      // Keep the last occurrence in this file; the import preview reports no
      // silent duplicate deletion because duplicate handling can be refined.
      parsed.removeWhere((o) => o.keyValue == key);
    }

    parsed.add(FmsOrder(
      keyValue: key,
      trackingNumber: tracking,
      orderId: orderId,
      orderSn: orderSn,
      status: _value(row, ['Status', 'Order Status', 'Status Log']).isEmpty
          ? 'Unknown'
          : _value(row, ['Status', 'Order Status', 'Status Log']),
      account: _value(row, ['Order Account']),
      currentStation: _value(row, ['Current Station']),
      destinationStation: _value(row, ['Destination Station']),
      createdTime: _value(row, ['Created Time', 'Create Time']),
      rawJson: jsonEncode(row),
    ));
  }

  final warnings = <String>[];
  if (skipped > 0) warnings.add('$skipped row(s) skipped because no order key was found.');
  if (parsed.isEmpty) warnings.add('No valid order rows were found.');
  return CsvImportResult(
    orders: parsed,
    rowsRead: rows.length > 1 ? rows.length - 1 : 0,
    skippedRows: skipped,
    warnings: warnings,
  );
}
